from utils import read_video, save_video, get_center_of_bbox
from trackers import Tracker, TrackerBat
from view_transformer import ViewTransformer, ViewTransformerBat
from speed_and_distance_estimator import SpeedAndDistance_Estimator, SpeedAndDistance_EstimatorBat

def main():
    # Read Video
    video_frames = read_video("input_videos/model_video.mp4")

    tracker = Tracker('models/best.pt')

    tracks = tracker.get_object_tracks(video_frames, read_from_stub=True, stub_path='stubs/track_stubs.pkl')

    tracker_bat = TrackerBat('models_bat/best.pt')

    tracks_bat = tracker_bat.get_object_tracks(video_frames, read_from_stub=True, stub_path='stubs/track_bat_stubs.pkl')

    # Interpolate Bat
    tracks_bat["bat"] = tracker_bat.interpolate_bat_positions(tracks_bat["bat"])
    tracker_bat.add_position_to_tracks(tracks_bat)

    # Interpolate Baseball
    tracks["baseball"] = tracker.interpolate_ball_positions(tracks["baseball"])
    tracker.add_position_to_tracks(tracks)

    # View Transformer
    view_transformer = ViewTransformer()
    view_transformer.add_transformed_position_to_tracks(tracks)

    view_transformer_bat = ViewTransformerBat()
    view_transformer_bat.add_transformed_position_to_tracks(tracks_bat)

    # Speed and distance estimator
    speed_and_distance_estimator = SpeedAndDistance_Estimator()
    speed_and_distance_estimator.add_speed_and_distance_to_tracks(tracks)

    speed_and_distance_estimator_bat = SpeedAndDistance_EstimatorBat()
    speed_and_distance_estimator_bat.add_speed_and_distance_to_tracks(tracks_bat)

    tracks.update(tracks_bat)

    shadows = 9

    tracks_ball_shadow = {
        f"baseball_shadow{i + 1}": ([{}] * (i + 1)) + tracks["baseball"][:len(tracks["baseball"]) - (i + 1)] for i in
                   range(shadows)
    }
    tracks.update(tracks_ball_shadow)

    tracks_bat_shadow = {
        f"bat_shadow{i + 1}": ([{}] * (i + 1)) + tracks["bat"][:len(tracks["bat"]) - (i + 1)] for i in range(shadows)
    }

    tracks.update(tracks_bat_shadow)

    distances = speed_and_distance_estimator_bat.contact_bat_ball(tracks)
    freeze_index = distances.index(min(distances))

    batter_center = get_center_of_bbox(tracks["batter"][0][1]["bbox"])

    # Draw output
    #output_video_frames = tracker.draw_annotations(video_frames, tracks)
    tracks = tracker_bat.shadow_freeze(video_frames, tracks, freeze_index, shadows)

    ball_distance = [x.get(1, {}).get('distance', 0) for x in tracks["baseball"]]
    max_ball_distance = max(ball_distance)


    output_video_frames_bat = tracker_bat.draw_annotations(video_frames, tracks, shadows, batter_center, freeze_index)
    output_video_frames_bat = speed_and_distance_estimator_bat.draw_speed_distance_rectangle(
        output_video_frames_bat, tracks, freeze_index, max_ball_distance)

    # Draw Speed and Distance
    speed_and_distance_estimator_bat.draw_speed_and_distance(output_video_frames_bat,tracks)

    # Save Video
    #save_video(output_video_frames, "output_videos/output_video.avi")
    save_video(output_video_frames_bat, freeze_index, "output_videos/output_video.avi")

if __name__ == "__main__":
    main()